=== Hello Dolly ===
Contributors: matt, wordpressdotorg
Stable tag: 1.7.2
Tested up to: 6.9
Requires at least: 4.6

This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.

== Description ==

This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.

Thanks to Sanjib Ahmad for the artwork.
