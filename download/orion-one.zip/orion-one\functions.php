<?php
/**
 * Orion One Theme Functions
 */

function orion_one_setup() {
    // Register Navigation Menus
    register_nav_menus(array(
        'primary' => 'Primary Menu',
        'footer'  => 'Footer Menu'
    ));
}
add_action('after_setup_theme', 'orion_one_setup');
