    </main>
    <footer class="bg-white border-t border-gray-200 mt-12 py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <p class="text-slate-500 text-sm">&copy; <?php echo date('Y'); ?> Orion Member System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
