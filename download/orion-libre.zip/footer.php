    </main>
    <footer class="bg-libre-900 text-libre-200 py-8 mt-auto border-t-4 border-libre-600">
        <div class="container mx-auto px-4 text-center">
            <p class="font-serif italic text-lg mb-4">"A room without books is like a body without a soul."</p>
            <p class="text-sm text-libre-400">&copy; <?php echo date('Y'); ?> <?php echo get_option('blogname'); ?>. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>
