<?php
/**
 * Orion PMC Theme Functions
 */

// Add any theme-specific logic here
