<?php
// Redirect to new location in root
header("Location: /orion/product-manager.php");
exit;
?>